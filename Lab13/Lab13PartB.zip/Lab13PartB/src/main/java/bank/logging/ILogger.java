package bank.logging;

public interface ILogger {
    public void log (String logstring);
}
