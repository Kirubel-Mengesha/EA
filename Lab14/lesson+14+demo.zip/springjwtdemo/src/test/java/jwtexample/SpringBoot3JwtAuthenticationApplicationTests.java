package jwtexample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBoot3JwtAuthenticationApplicationTests {

	@Test
	void contextLoads() {
	}

}
