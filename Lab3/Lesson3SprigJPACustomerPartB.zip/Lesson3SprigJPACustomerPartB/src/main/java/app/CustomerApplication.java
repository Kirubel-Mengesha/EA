package app;

import java.util.List;
import java.util.Optional;

import domain.Book;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import repositories.BookRepository;
import repositories.CustomerRepository;
import domain.Customer;

@SpringBootApplication
@EnableJpaRepositories("repositories")
@EntityScan("domain") 
public class CustomerApplication implements CommandLineRunner{
	
	@Autowired
	CustomerRepository customerrepository;

	@Autowired
	BookRepository bookRepository;

	public static void main(String[] args) {
		SpringApplication.run(CustomerApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		customerrepository.save(new Customer("Jack", "Bauer", "jack@acme.com"));
		customerrepository.save(new Customer("Chloe", "O'Brian", "chloe@acme.com"));
		customerrepository.save(new Customer("Kim", "Bauer", "kim@acme.com"));
		customerrepository.save(new Customer("David", "Palmer", "dpalmer@gmail.com"));
		customerrepository.save(new Customer("Michelle", "Dessler", "mich@hotmail.com"));


		// fetch all customers
		System.out.println("Customers found with findAll():");
		System.out.println("-------------------------------");
		for (Customer customer : customerrepository.findAll()) {
			System.out.println(customer);
		}
		System.out.println();

		// fetch an individual customer by ID
		Optional<Customer> custOpt = customerrepository.findById(1L);
		Customer customer = custOpt.get();
		System.out.println("Customer found with findOne(1L):");
		System.out.println("--------------------------------");
		System.out.println(customer);
		System.out.println();


		// Save some books
		bookRepository.save(new Book("Book One", "111-111", "Author One", 19.99));
		bookRepository.save(new Book("Book Two", "222-222", "Author Two", 29.99));
		bookRepository.save(new Book("Book Three", "333-333", "Author Three", 39.99));

		// Retrieve all books
		System.out.println("Books found with findAll():");
		System.out.println("-------------------------------");
		for (Book book : bookRepository.findAll()) {
			System.out.println(book);
		}
		System.out.println();

		// Update a book
		Optional<Book> bookOpt = bookRepository.findById(6);
		if (bookOpt.isPresent()) {
			Book book = bookOpt.get();
			book.setPrice(24.99);
			bookRepository.save(book);
		} else {
			System.out.println("Book with ID 6 not found.");
		}

		// Delete a book (not the book that was just updated)
		bookOpt = bookRepository.findById(7);
		if (bookOpt.isPresent()) {
			bookRepository.deleteById(7);
		} else {
			System.out.println("Book with ID 7 not found.");
		}

		// Retrieve all books again
		System.out.println("Books found with findAll() after update and delete:");
		System.out.println("-------------------------------");
		for (Book b : bookRepository.findAll()) {
			System.out.println(b);
		}
		System.out.println();
	}
}
