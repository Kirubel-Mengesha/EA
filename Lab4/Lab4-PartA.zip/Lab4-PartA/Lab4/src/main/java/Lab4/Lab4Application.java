package Lab4;

import Lab4.partB.Domain.Book;
import Lab4.partA.Domain.Department;
import Lab4.partA.Domain.Employee;
import Lab4.partB.Domain.Publisher;
import Lab4.partB.Repository.BookRepository;
import Lab4.partA.Repository.DepartmentRepository;
import Lab4.partA.Repository.EmployeeRepository;
import Lab4.partB.Repository.PublisherRepository;
import Lab4.partC.Domain.Flight;
import Lab4.partC.Domain.Passenger;
import Lab4.partC.Repository.FlightRepository;
import Lab4.partC.Repository.PassengerRepository;
import Lab4.partD.Domain.School;
import Lab4.partD.Domain.Student;
import Lab4.partD.Repository.SchoolRepository;
import Lab4.partD.Repository.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@SpringBootApplication
public class Lab4Application implements CommandLineRunner {
	@Autowired
	private DepartmentRepository departmentRepository;
	@Autowired
	private EmployeeRepository employeeRepository;

	@Autowired
	private BookRepository bookRepository;

	@Autowired
	private PublisherRepository publisherRepository;

	@Autowired
	private PassengerRepository passengerRepository;
	@Autowired
	private FlightRepository flightRepository;
	@Autowired
	private SchoolRepository schoolRepository;

	@Autowired
	private StudentRepository studentRepository;

	public static void main(String[] args) {
		SpringApplication.run(Lab4Application.class, args);
	}


	@Override
	public void run(String... args) throws Exception {

		Department department = new Department();
		department.setName("HR");

		Employee employee1 = new Employee();
		employee1.setName("frank");
		Employee employee2 = new Employee();
		employee2.setName("ocean");

		department.add(employee1);
		department.add(employee2);

		departmentRepository.save(department);
		employeeRepository.save(employee1);
		employeeRepository.save(employee2);

		System.out.println("-----Department with employeeList-------");
		System.out.println(department);
		System.out.println();

		Publisher publisher = new Publisher();
		publisher.setName("Publisher 1");
		publisherRepository.save(publisher);

		Book book1 = new Book("Book Title 1","Rene");
		book1.setPublisher(publisher);
		bookRepository.save(book1);

		Book book2 = new Book("Book Title 2", "Eric Ten Hag");
		book2.setPublisher(publisher);
		bookRepository.save(book2);


		System.out.println("-----Publisher-------");
		System.out.println(publisher);
		System.out.println();

		System.out.println("-----Book1-------");
		Optional<Book> bookOpt = bookRepository.findById(1L);
		Book books = bookOpt.get();
		System.out.println(book1);

		System.out.println();




		Flight flight1 = new Flight(10034,"SanFrancisco", "Boston", new Date());
		Flight flight2 = new Flight(10045,"Iowa", "Chicago", new Date());
		Passenger passenger = new Passenger("james Bond");

		passenger.addFlight(flight1);
		passenger.addFlight(flight2);

		passengerRepository.save(passenger);
		flightRepository.save(flight1);
		flightRepository.save(flight2);

		System.out.println("-----Passenger with their flights-------");
		List<Passenger> passengerList = passengerRepository.findAll();
		System.out.println(passengerList);

		System.out.println();



		School school = new School("MIU");
		Student student1 = new Student(1, "Frank","Brown");
		Student student2 = new Student(2, "John","Doe");

		school.addStudent(student1);
		school.addStudent(student2);

		schoolRepository.save(school);

		System.out.println("-----School with their Students-------");
		List<School> schoolOpt = schoolRepository.findAll();
		System.out.println(schoolOpt);






	}
}
