package Lab4.partB.Repository;

import Lab4.partB.Domain.Book;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BookRepository extends JpaRepository<Book, Long> {
}
