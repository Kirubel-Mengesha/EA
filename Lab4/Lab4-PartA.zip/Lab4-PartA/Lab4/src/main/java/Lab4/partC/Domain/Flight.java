package Lab4.partC.Domain;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Date;

@Entity
@Getter
@Setter
@NoArgsConstructor
public class Flight {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    private long flightNumber;
    @Column(name="leavingFrom")
    private String from;
    @Column(name="goingTo")
    private String to;
    @Temporal(TemporalType.DATE)
    private Date date;

    public Flight(long flightNumber, String from, String to, Date date) {
        this.flightNumber = flightNumber;
        this.from = from;
        this.to = to;
        this.date = date;
    }

    @Override
    public String toString() {
        return "Flight{" +
                "id=" + id +
                ", flightNumber=" + flightNumber +
                ", leavingFrom='" + from + '\'' +
                ", goingTo='" + to + '\'' +
                ", date=" + date +
                '}';
    }
}
