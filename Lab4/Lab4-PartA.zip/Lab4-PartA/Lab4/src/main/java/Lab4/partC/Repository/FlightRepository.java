package Lab4.partC.Repository;

import Lab4.partC.Domain.Flight;
import Lab4.partC.Domain.Passenger;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FlightRepository extends JpaRepository<Flight, Long> {
}
