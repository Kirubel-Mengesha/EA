package Lab4.partD.Domain;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.HashMap;
import java.util.Map;

@Entity
@Getter
@Setter
@NoArgsConstructor
public class School {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    private String name;

    @OneToMany(cascade = CascadeType.PERSIST, fetch = FetchType.EAGER)
    @MapKey(name = "studentId")
    private Map<Long, Student> students = new HashMap<>();

    public School(String name) {
        this.name = name;
    }

    public Student addStudent(Student student) {
        return students.put(student.getStudentId(), student);
    }
    public Student removeStudent(Student student) {
        return students.remove(student);
    }

    @Override
    public String toString() {
        return "School{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", students=" + students +
                '}';
    }
}
