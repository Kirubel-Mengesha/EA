package domain;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.Entity;

@Entity
@Getter
@Setter
@NoArgsConstructor
public class CD extends Product{

    private String artist;

    public CD(String artist) {
        this.artist = artist;
    }

    public CD(String name, double price, String artist) {
        super(name, price);
        this.artist = artist;
    }
}

