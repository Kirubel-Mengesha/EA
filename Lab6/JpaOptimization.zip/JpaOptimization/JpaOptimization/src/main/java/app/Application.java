package app;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.List;


@SpringBootApplication
public class Application implements CommandLineRunner{
	
	@Autowired
	CustomerRepository customerRepository;
	@Autowired
	SchoolRepository schoolRepository;

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		insertCustomers();
		retrieveCustomers();
		updateCustomers();

		insertSchools();
		retrieveSchools();
		retrieveSchoolsWithStudents();
	}

	private void insertCustomers() {
		for (int x=0; x<5000; x++) {
			Customer customer = new Customer("John Doe "+x);
			Account account = new Account("123"+x);
			customer.setAccount(account);
			customerRepository.save(customer);
			System.out.println("Inserting customer  "+x);
		}
	}

	private void retrieveCustomers() {
		System.out.println("Retrieving all customers ...");
		long start = System.currentTimeMillis();

		List<Customer> customers = customerRepository.findAllWithAccounts();
		long finish = System.currentTimeMillis();
		long timeElapsed = finish - start;
		System.out.println("To retrieve all Customers took "+timeElapsed+" ms");
	}

	private void updateCustomers() {
		System.out.println("Change the name of all customers ...");
		long start = System.currentTimeMillis();

		List<Customer> customers = customerRepository.findAll();
		for(Customer c: customers){
			c.setName("James Bond");
			customerRepository.save(c);
		}
		long finish = System.currentTimeMillis();
		long timeElapsed = finish - start;
		System.out.println("To change the name of all customers took "+timeElapsed+" ms");
	}

	private void insertSchools() {
		for (int i = 0; i < 100; i++) {
			School school = new School("MIU " + i);
			for (int j = 0; j < 1000; j++) {
				Student student = new Student("Eric " + j, "Ten Hag " + j, "tenhag " + j + "@manutd " + i + ".com");
				student.setSchool(school);
				school.getStudents().add(student);
			}
			schoolRepository.save(school);
			System.out.println("Inserting school " + i);
		}
	}

	private void retrieveSchools() {
		System.out.println("Retrieving all schools ...");
		long start = System.currentTimeMillis();

		List<School> schools = schoolRepository.findAll();
		long finish = System.currentTimeMillis();
		long timeElapsed = finish - start;
		System.out.println("To retrieve all Schools took " + timeElapsed + " ms");
	}

	private void retrieveSchoolsWithStudents() {
		System.out.println("Retrieving all schools with students ...");
		long start = System.currentTimeMillis();

		List<School> schools = schoolRepository.findAllWithStudents();
		for (School school : schools) {
			System.out.println("School: " + school.getName());
			for (Student student : school.getStudents()) {
				System.out.println("Student: " + student.getFirstname() + " " + student.getLastname());
			}
		}

		long finish = System.currentTimeMillis();
		long timeElapsed = finish - start;
		System.out.println("To retrieve all Schools with students took " + timeElapsed + " ms");
	}


}
