package app;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
public class Student {
    @Id
    @GeneratedValue
    private long id;
    private String firstname;
    private String lastname;
    private String emailaddress;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "school_id")
    private School school;

    protected Student() {}

    public Student(String firstname, String lastname, String emailaddress) {
        this.firstname = firstname;
        this.lastname = lastname;
        this.emailaddress = emailaddress;
    }


}
