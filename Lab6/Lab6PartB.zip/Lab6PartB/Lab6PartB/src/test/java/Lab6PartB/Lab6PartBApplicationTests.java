package Lab6PartB;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab6PartBApplicationTests {

	@Test
	void contextLoads() {
	}

}
